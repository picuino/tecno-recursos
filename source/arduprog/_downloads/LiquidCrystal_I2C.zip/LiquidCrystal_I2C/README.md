LiquidCrystal_I2C
=================

A reimplementation of the standard Arduino LCD library, configured 
to work with parallel HD44780 compatible LCDs, and interfaced via a 
Chinese PCF8574 I2C serial extender.