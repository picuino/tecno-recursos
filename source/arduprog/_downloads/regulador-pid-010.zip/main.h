/*
    Declaration file for main.c
*/

#ifndef MAIN_H
#define MAIN_H

float feed_forward(float temp);       // Line  169
float interpola(float x);             // Line  175
void isr_high(void);                  // Line   35
void isr_low(void);                   // Line   40
float pid(float error);               // Line  145,   1 calls
void pwm_init(void);                  // Line   53,   1 calls
void pwm_write(float d);              // Line  123,   1 calls
void rs232_init(void);                // Line   90,   1 calls
float temperature(unsigned int adc);  // Line  132,   1 calls

#endif