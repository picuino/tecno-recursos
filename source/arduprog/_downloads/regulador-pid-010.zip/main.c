/****************************************************************************
   Control digital de temperatura de horno.
   (cc) Picuino Marzo 2013
 ****************************************************************************/
#include <p18cxxx.h>
#include <stdio.h>
#include <math.h>

#include "adc.h"
#include "config.h"


/****************************************************************************
      HARDWARE DEFINITIONS AND GLOBAL VARS
 ****************************************************************************/
static unsigned int clock;

typedef struct {
   float Kp;              // Ganancia proporcional
   float Ki;              // Ganancia integral
   float Kd;              // Ganancia derivativa
   float T;               // Tiempo de muestreo
   float integral;        // Valor del control integral
   float MaxIntegralError; // Antiwindup. Error m�nimo para que funcione el control integral
   float error_0;         // Error del ciclo anterior
   float ff_const;        // Ganancia del control feedforward
   float ambiente;        // Temperatura ambiente
   float consigna;        // Temperatura de consigna
} PID;

static PID pid1;

static char kb_old, kbst;  // keyboard state 


/****************************************************************************
      INTERRUPTS
 ****************************************************************************/
#pragma interrupt isr_low_main
void isr_low_main(void) {
   PORTAbits.RA1 = 1;
   if (PIR1bits.TMR2IF == 1) {
      PIR1bits.TMR2IF = 0; 
      clock++;
   }
   PORTAbits.RA1 = 0;
}


#pragma code high_vector=0x08
void isr_high(void) {
   _asm GOTO isr_low_main  _endasm
}

#pragma code low_vector=0x18
void isr_low(void) {
   _asm GOTO isr_low_main  _endasm
}

#pragma code


/****************************************************************************
      INIT HARDWARE
 ****************************************************************************/
/*
   PIC18F2550 PWM init
*/
void pwm_init(void) {
   PR2 = 99;   // PWM frequency = Fosc / [(PR2+1)�4�(TMR2 Prescale Value)]
   TMR2 = 0;   // Timer2 Initial value
   CCPR1L = 0; // PWM duty cycle
   T2CON = (char)
      +(0<<3)  // T2OUTPS: Timer2 Output Postscale Select bits
               //    0 = 1:1 Postscale
               //    1 = 1:2 Postscale
               //    � � � 
               //    15 = 1:6 Postscale
      +(1<<2)  // TMR2ON: Timer2 On bit. 1 = Timer2 is on
      +(1);    // T2CKPS: Timer2 Clock Prescale Select bits
               //    0 = Prescaler is 1
               //    1 = Prescaler is 4
               //    2,3 = Prescaler is 16
   CCP1CON =  (char) 
      +(0<<4)  // DC1B: PWM Duty Cycle Bit 1 and Bit 0 for CCP1
     +(0b1100);// CCP1M: CCP1 Module Mode Select bits
               // 0000 = Capture/Compare/PWM disabled (resets CCPx module)
               // 0001 = Reserved
               // 0010 = Compare mode: toggle output on match (CCP1IF bit is set)
               // 0100 = Capture mode: every falling edge
               // 0101 = Capture mode: every rising edge
               // 0110 = Capture mode: every 4th rising edge
               // 0111 = Capture mode: every 16th rising edge
               // 1000 = Compare mode: initialize CCP1 pin low; on compare match, force CCP1 pin high (CCP1IF bit is set)
               // 1001 = Compare mode: initialize CCP1 pin high; on compare match, force CCP1 pin low (CCP1IF bit is set)
               // 1010 = Compare mode: generate software interrupt on compare match (CCPxIF bit is set, CCPx pin reflects I/O state)
               // 1011 = Compare mode: trigger special event, reset timer, start A/D conversion on CCPx match (CCPxIF bit is set)
               // 11xx = PWM mode
   TRISCbits.TRISC2 = 0;
}


/*
  Initialize USART for RS232 comunications
*/
void rs232_init(void) {
   PIE1bits.TXIE = 0;         // Disable RS232 interrupts
   PIR1bits.TXIF = 0;

   SPBRGH = 0;
   SPBRG = 12; ((FOSC/(8*BAUD))-1)/2;    // Real Baud = FOSC/(16*(SPBRG+1)) 

   BAUDCON = (char)
           (0<<7)    // ABDOVF: 0 = No BRG rollover has occurred
         + (0<<6)    // RCIDL:  0 = Receive operation is active
         + (0<<5)    // RXDTP:  1 = RX data is inverted
         + (0<<4)    // TXCKP:  1 = TX data is inverted
         + (0<<3)    // BRG16:  1 = 16-bit Baud Rate Generator � SPBRGH
         + (0<<1)    // WUE:    0 = RX pin not monitored or rising edge detected
         + (0<<0);   // ABDEN:  0 = Baud rate measurement disabled or completed

   TXSTA = (char)
           (0<<7)    // CSRC:  1 = Syncronous Master mode
         + (0<<6)    // TX9:   1 = Selects 9-bit transmission
         + (1<<5)    // TXEN:  1 = Transmit enabled
         + (0<<4)    // SYNC:  1 = Synchronous mode
         + (0<<3)    // SENDB: 1 = Asynchronous mode: Send Sync Break on next transmission (cleared by hardware upon completion)
         + (1<<2)    // BRGH:  1 = Asynchronous mode: High speed
         + (1<<1)    // TRMT:  1 = TSR empty
         + (0<<0);   // TX9D:  Ninth bit of Transmit Data

   RCSTA = (char)
           (1<<7)    // SPEN:  1 = Serial port enabled
         + (0<<6)    // RX9:   1 = Selects 9-bit reception
         + (0<<5)    // SREN:  1 = Enables single receive in Master Synchronous mode
         + (1<<4)    // CREN:  1 = Enables Continuous Receive
         + (0<<3)    // ADDEN: 1 = Enables address detection (RX9 = 1)
         + (0<<2)    // FERR:  1 = Framing error
         + (0<<1)    // OERR:  1 = Overrun error (can be cleared by clearing bit CREN)
         + (0<<0);   // RX9D:  Ninth bit of Received Data

}

/*
   Init ADC
   Select input pin to sample and hold circuit
*/
void adc_init(unsigned char channel) {
   // Configure ADC
   ADCON0 = (char)
         (channel<<2) // CHS: Analog Channel Select bits. [0 .. 12]
         + (0<<1)     // GO/DONE: A/D Conversion Status bit. 0 = Done 
         + (1<<0);    // ADON: A/D On bit. 1 = On
   ADCON1 = (char)
           (0<<5)  // VCFG1: Voltage Reference Configuration bit
                   //   1 = VREF- (AN2)
                   //   0 = VSS
         + (0<<4)  // VCFG0: Voltage Reference Configuration bit
                   //   1 = VREF+ (AN3)
                   //   0 = VDD
         + (14<<0);// PCFG: A/D Port Configuration Control bits
                   //    0,1,2 = All analog
                   //    3 = AN12 digital; AN11,AN10,AN9,AN8,AN4,AN3,AN2,AN1,AN0 analog
                   //    4 = AN12,AN11 digital; AN10,AN9,AN8,AN4,AN3,AN2,AN1,AN0 analog
                   //   14 = AN12,AN11,AN10,AN9,AN8,AN4,AN3,AN2,AN1 digital, AN0 analog
                   //   15 = AN12,AN11,AN10,AN9,AN8,AN4,AN3,AN2,AN1,AN0 digital
   ADCON2 = (char)
           (1<<7)  // ADFM:  1 = A/D Result Right justified
         + (1<<3)  // ACQT:  A/D Acquisition Time Select
                   //   7 = 20 TAD
                   //   6 = 16 TAD
                   //   5 = 12 TAD
                   //   4 =  8 TAD
                   //   3 =  6 TAD
                   //   2 =  4 TAD
                   //   1 =  2 TAD
                   //   0 =  0 TAD
         + (5<<3); // ADCS:  A/D Conversion Clock Select bits
                   //   7,3 = FRC (clock derived from A/D RC oscillator)
                   //   6 = FOSC/64  Fosc max = 48MHz
                   //   2 = FOSC/32  Fosc max = 40MHz
                   //   5 = FOSC/16  Fosc max = 20MHz
                   //   1 = FOSC/8   Fosc max = 10MHz
                   //   4 = FOSC/4   Fosc max =  5MHz
                   //   0 = FOSC/2   Fosc max =  2.50MHz
}


/****************************************************************************
      FUNCTIONS
 ****************************************************************************/

/*
   Read Analog Input
*/
unsigned short adc_read(unsigned char channel) {
   union {
      struct {
          unsigned char lob;
          unsigned char hib;
      };
      unsigned short word;
   } adc_val;
   
   // Configure ADC
   adc_init(channel);

   // GO ADC conversion
   ADCON0bits.GO = 1;          // ADC Hold and Start conversion
   while (ADCON0bits.GO == 1); // Conversion

   // Return ADC conversion
   adc_val.lob = ADRESL;
   adc_val.hib = ADRESH;
   return adc_val.word;
}


/*
   Escribe el valor de la salida PWM
*/
void pwm_write(float d) {
   if (d>100.0) 
      CCPR1L = 100;
   else if (d<0.0) 
      CCPR1L = 0;
   else
      CCPR1L = d;
}


/*
   Calcula la temperatura medida por la resistencia NTC
   a partir del valor le�do por el conversor ADC
*/
float temperatura(unsigned int adc) {
   float r_ntc, temp;

   #define RTH_POL 10000  // Resistencia de polarizaci�n
   #define RTH_A   -0.8272 // Constantes del termistor
   #define RTH_B   3006.0

   r_ntc = (1023.0 * RTH_POL)/adc - RTH_POL;
   temp = RTH_B/(log(r_ntc) - (RTH_A)) - 273.15;

   return temp;
}


/*
   Inicializa las constantes del controlador PID
*/
void pid_init(PID *pid, float Kp, float Ki, float Kd, float MaxI) {
   pid->Kp = Kp;
   pid->Ki = Ki;
   pid->Kd = Kd;
   pid->integral = 0.0;
   pid->error_0 = 0.0;
   pid->MaxIntegralError = MaxI;
}


/*
   Calcula el control PID
*/
float pid_calc(float error, PID *pid) {
   static float control;
   static float proporcional, integral, derivativo;

   // Calcula el t�rmino Proporcional
   proporcional = error * pid->Kp;

   // Calcula el t�rmino Integral con limitaci�n anti-windup
   integral = pid->integral;
   if (fabs(error) < pid->MaxIntegralError) {
      integral = integral + error * pid->Ki * pid->T;
      if (integral>100.0) integral = 100.0;
      if (integral<-100.0)   integral = -100.0;
   }
   else
      integral = 0.0;
   pid->integral = integral;

   // Calcula el t�rmino Derivativo
   derivativo = (error - pid->error_0) * pid->Kd / pid->T;
   pid->error_0 = error;

   // Suma todos los t�rminos
   control = proporcional + integral + derivativo;
       
   return control;
}


/*
   Calcula el control Feedforward
*/
int feedforward(PID *pid) {
   return (pid->consigna - pid->ambiente) * pid->ff_const;
}

/*
   Aumenta o disminuye el valor de la constante.
   En 15 pasos se aumenta el valor al doble.
   En 18 pasos se disminuye el valor a la mitad.
*/
void float_up(float *p)   { *p *= 1.0473; }
void float_down(float *p) { *p /= 1.03926; }

/*
   Leer el teclado y actualizar las constantes del controlador PID
*/
void kb_read(PID *pid) {
   static char print;
   print = 0;

   // Escoge la constante a cambiar
   if (PORTAbits.RA1==1 && (kb_old & (1<<1))==0) {
      if (++kbst > 4) kbst = 0;
      print = 1;
   }

   // Incrementa constante
   if (PORTAbits.RA2==1 && (kb_old & (1<<2))==0) {
      switch(kbst) {
      case 0: float_up(&pid->Kp); break;
      case 1: float_up(&pid->Ki);  break;
      case 2: float_up(&pid->Kd);  break;
      case 3: float_up(&pid->MaxIntegralError);  break;
      case 4: float_up(&pid->consigna); break;
      }
      print = 1;
   }

   // Decrementa constante
   if (PORTAbits.RA3==1 && (kb_old & (1<<3))==0) {
      switch(kbst) {
      case 0: float_down(&pid->Kp); break;
      case 1: float_down(&pid->Ki);  break;
      case 2: float_down(&pid->Kd);  break;
      case 3: float_down(&pid->MaxIntegralError);  break;
      case 4: float_down(&pid->consigna); break;
      }  
      print = 1;
   }

   // Imprime constante
   if (print == 1) {
      switch(kbst) {
      case 0:  printf("Kp=%d\t", (int)(pid->Kp*10));  break;
      case 1:  printf("Ki=%d\t", (int)(pid->Ki*10));  break;
      case 2:  printf("Kd=%d\t", (int)(pid->Kd*10));  break;
      case 3:  printf("MaxInt=%d\t", (int)(pid->MaxIntegralError*10));  break;
      case 4:  printf("Consigna=%d\t", (int)(pid->consigna*10));
      }  
   }
   
   // Almacena estado del Puerto A
   kb_old = PORTA;
}


/****************************************************************************
      MAIN PROGRAM
 ****************************************************************************/
void main(void) {
   int adc_temp;
   float sensor, error, control;
   PID pid1;

   //*********************************
   //   Inicializaci�n
   //*********************************
   TRISA = 0b11111111;
   TRISCbits.TRISC2 = 0; // PWM out
   
   adc_init(0);
   pwm_init();
   rs232_init();

   // Inicializa interrupciones
   INTCONbits.GIE = 1;
   INTCONbits.PEIE = 1;
   PIE1bits.TMR2IE = 1;

   // Inicializa las constantes del controlador PID
   pid_init(&pid1, 50.0, 0.0, 0.0, 5.0);  // Kp, Ki, Kd, MaxIntegralError
   pid1.T = 1.0;                     // Tiempo de ciclo
   pid1.ambiente = 20.0;             // Temperatura ambiente
   pid1.ff_const = 41.0/30.0;        // Constante feedforward
   pid1.consigna = 50.0;             // Consigna o valor de temperatura deseado

   // Inicializa teclado
   kb_old = 0;
   kbst = 0;

   printf("System OK\r\n");

  
   //*********************************
   //   Programa principal
   //*********************************  

   while(1) {

      // Lee la se�al del sensor
      adc_temp = adc_read(0);
      sensor = temperatura(adc_temp);

      // Calcula la se�al de error 
      error = pid1.consigna - sensor;

      // Calcula la se�al de control
      control = pid_calc(error, &pid1); // + feedforward(&pid1);
 
      // Escribe la se�al de control en el conversor DAC
      pwm_write(control);


      // Escribe los valores del controlador en el puerto RS232
      printf("adc =\t%d\t", adc_temp);
      printf("temp =\t%d\t", (int)(sensor*10));
      printf("error =\t%d\t", (int)(error*10));
      printf("Integral =\t%d\t", (int)(pid1.integral*10));
      printf("control =\t%d\t", (int)control);


      // Espera T segundos (tiempo o per�odo de muestreo)
      while(clock < 12500) {
         kb_read(&pid1); // modificar constantes
      };
      clock = 0;
      printf("\r\n");
   }
}