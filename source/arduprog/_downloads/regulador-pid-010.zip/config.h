/*
	Picuino Frequency counter Firmware
    Configuration file
*/

#ifndef CONFIG_H
#define CONFIG_H

#define FOSC 20000000    // clock oscillator
#define BAUD 115200      // usart baud speed

#endif