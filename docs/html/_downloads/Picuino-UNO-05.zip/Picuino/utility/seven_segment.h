/*
    Declaration file for seven_seg.c
*/

#ifndef __SEVEN_SEG_H
#define __SEVEN_SEG_H


// Seven Segment code of chars
#define SS_0    0b11111100  // 0
#define SS_1    0b01100000  // 1
#define SS_2    0b11011010  // 2
#define SS_3    0b11110010  // 3
#define SS_4    0b01100110  // 4
#define SS_5    0b10110110  // 5
#define SS_6    0b10111110  // 6
#define SS_7    0b11100000  // 7
#define SS_8    0b11111110  // 8
#define SS_9    0b11110110  // 9
#define SS_A    0b11101110  // A
#define SS_b    0b00111110  // b
#define SS_B    0b11111110  // b
#define SS_C    0b10011100  // C
#define SS_d    0b01111010  // d
#define SS_E    0b10011110  // E
#define SS_F    0b10001110  // F
#define SS_G    0b10111100  // G
#define SS_g    0b11110110  // g
#define SS_H    0b01101110  // H
#define SS_h    0b00101110  // h
#define SS_I    0b01100000  // I
#define SS_i    0b00100000  // i
#define SS_J    0b01111000  // J
#define SS_K    0b00001110  // K
#define SS_L    0b00011100  // L
#define SS_n    0b00101010  // n
#define SS_ny   0b10101010  // ñ
#define SS_o    0b00111010  // o
#define SS_O    0b11111100  // O
#define SS_P    0b11001110  // P
#define SS_q    0b11100110  // q
#define SS_r    0b00001010  // r
#define SS_S    0b10110110  // S
#define SS_t    0b00011110  // t
#define SS_u    0b00111000  // u
#define SS_U    0b01111100  // U
#define SS_y    0b01100110  // y
#define SS_Y    0b01110110  // Y
#define SS_Z    0b11011010  // Z

#define SS_SP   0b00000000  // BLANK SPACE

#endif






