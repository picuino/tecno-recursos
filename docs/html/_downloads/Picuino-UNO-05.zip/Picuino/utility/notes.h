/****************************************************************
   MUSICAL NOTES
 ****************************************************************/

#ifndef __NOTES_H
#define __NOTES_H

#define  Do         12   // Do1
#define  Do_        13
#define  Re         14
#define  Re_        15
#define  Mi         16
#define  Fa         17
#define  Fa_        18
#define  Sol        19
#define  Sol_       20
#define  La         21
#define  La_        22
#define  Si         23

#define  Do0        0   // F =   16,35 Hz
#define  Do_0       1   // F =   17,32 Hz
#define  Re0        2   // F =   18,35 Hz
#define  Re_0       3   // F =   19,45 Hz
#define  Mi0        4   // F =   20,60 Hz
#define  Fa0        5   // F =   21,83 Hz
#define  Fa_0       6   // F =   23,12 Hz
#define  Sol0       7   // F =   24,50 Hz
#define  Sol_0      8   // F =   25,96 Hz
#define  La0        9   // F =   27,50 Hz
#define  La_0      10   // F =   29,14 Hz
#define  Si0       11   // F =   30,87 Hz
#define  Do1       12   // F =   32,70 Hz
#define  Do_1      13   // F =   34,65 Hz
#define  Re1       14   // F =   36,71 Hz
#define  Re_1      15   // F =   38,89 Hz
#define  Mi1       16   // F =   41,20 Hz
#define  Fa1       17   // F =   43,65 Hz
#define  Fa_1      18   // F =   46,25 Hz
#define  Sol1      19   // F =   49,00 Hz
#define  Sol_1     20   // F =   51,91 Hz
#define  La1       21   // F =   55,00 Hz
#define  La_1      22   // F =   58,27 Hz
#define  Si1       23   // F =   61,74 Hz
#define  Do2       24   // F =   65,41 Hz
#define  Do_2      25   // F =   69,30 Hz
#define  Re2       26   // F =   73,42 Hz
#define  Re_2      27   // F =   77,78 Hz
#define  Mi2       28   // F =   82,41 Hz
#define  Fa2       29   // F =   87,31 Hz
#define  Fa_2      30   // F =   92,50 Hz
#define  Sol2      31   // F =   98,00 Hz
#define  Sol_2     32   // F =  103,83 Hz
#define  La2       33   // F =  110,00 Hz
#define  La_2      34   // F =  116,54 Hz
#define  Si2       35   // F =  123,47 Hz
#define  Do3       36   // F =  130,81 Hz
#define  Do_3      37   // F =  138,59 Hz
#define  Re3       38   // F =  146,83 Hz
#define  Re_3      39   // F =  155,56 Hz
#define  Mi3       40   // F =  164,81 Hz
#define  Fa3       41   // F =  174,61 Hz
#define  Fa_3      42   // F =  185,00 Hz
#define  Sol3      43   // F =  196,00 Hz
#define  Sol_3     44   // F =  207,65 Hz
#define  La3       45   // F =  220,00 Hz
#define  La_3      46   // F =  233,08 Hz
#define  Si3       47   // F =  246,94 Hz
#define  Do4       48   // F =  261,63 Hz
#define  Do_4      49   // F =  277,18 Hz
#define  Re4       50   // F =  293,66 Hz
#define  Re_4      51   // F =  311,13 Hz
#define  Mi4       52   // F =  329,63 Hz
#define  Fa4       53   // F =  349,23 Hz
#define  Fa_4      54   // F =  369,99 Hz
#define  Sol4      55   // F =  392,00 Hz
#define  Sol_4     56   // F =  415,30 Hz
#define  La4       57   // F =  440,00 Hz
#define  La_4      58   // F =  466,16 Hz
#define  Si4       59   // F =  493,88 Hz
#define  Do5       60   // F =  523,25 Hz
#define  Do_5      61   // F =  554,37 Hz
#define  Re5       62   // F =  587,33 Hz
#define  Re_5      63   // F =  622,25 Hz
#define  Mi5       64   // F =  659,26 Hz
#define  Fa5       65   // F =  698,46 Hz
#define  Fa_5      66   // F =  739,99 Hz
#define  Sol5      67   // F =  783,99 Hz
#define  Sol_5     68   // F =  830,61 Hz
#define  La5       69   // F =  880,00 Hz
#define  La_5      70   // F =  932,33 Hz
#define  Si5       71   // F =  987,77 Hz
#define  Do6       72   // F = 1046,50 Hz
#define  Do_6      73   // F = 1108,73 Hz
#define  Re6       74   // F = 1174,66 Hz
#define  Re_6      75   // F = 1244,51 Hz
#define  Mi6       76   // F = 1318,51 Hz
#define  Fa6       77   // F = 1396,91 Hz
#define  Fa_6      78   // F = 1479,98 Hz
#define  Sol6      79   // F = 1567,98 Hz
#define  Sol_6     80   // F = 1661,22 Hz
#define  La6       81   // F = 1760,00 Hz
#define  La_6      82   // F = 1864,66 Hz
#define  Si6       83   // F = 1975,53 Hz
#define  Do7       84   // F = 2093,00 Hz
#define  Do_7      85   // F = 2217,46 Hz
#define  Re7       86   // F = 2349,32 Hz
#define  Re_7      87   // F = 2489,02 Hz
#define  Mi7       88   // F = 2637,02 Hz
#define  Fa7       89   // F = 2793,83 Hz
#define  Fa_7      90   // F = 2959,96 Hz
#define  Sol7      91   // F = 3135,96 Hz
#define  Sol_7     92   // F = 3322,44 Hz
#define  La7       93   // F = 3520,00 Hz
#define  La_7      94   // F = 3729,31 Hz
#define  Si7       95   // F = 3951,07 Hz
#define  Do8       96   // F = 4186,01 Hz
#define  Do_8      97   // F = 4434,92 Hz
#define  Re8       98   // F = 4698,64 Hz
#define  Re_8      99   // F = 4978,03 Hz
#define  Mi8      100   // F = 5274,04 Hz
#define  Fa8      101   // F = 5587,65 Hz
#define  Fa_8     102   // F = 5919,91 Hz
#define  Sol8     103   // F = 6271,93 Hz
#define  Sol_8    104   // F = 6644,88 Hz
#define  La8      105   // F = 7040,00 Hz
#define  La_8     106   // F = 7458,62 Hz
#define  Si8      107   // F = 7902,13 Hz
#define  Do9      108   // F = 8372,02 Hz
#define  Do_9     109   // F = 8869,84 Hz
#define  Re9      110   // F = 9397,27 Hz
#define  Re_9     111   // F = 9956,06 Hz
#define  Mi9      112   // F = 10548,08 Hz
#define  Fa9      113   // F = 11175,30 Hz
#define  Fa_9     114   // F = 11839,82 Hz
#define  Sol9     115   // F = 12543,85 Hz
#define  Sol_9    116   // F = 13289,75 Hz
#define  La9      117   // F = 14080,00 Hz
#define  La_9     118   // F = 14917,24 Hz
#define  Si9      119   // F = 15804,27 Hz
#define  Do10     120   // F = 16744,04 Hz
#define  Do_10    121   // F = 17739,69 Hz
#define  Re10     122   // F = 18794,55 Hz
#define  Re_10    123   // F = 19912,13 Hz
#define  Mi10     124   // F = 21096,16 Hz
#define  Fa10     125   // F = 22350,61 Hz
#define  Fa_10    126   // F = 23679,64 Hz
#define  Sol10    127   // F = 25087,71 Hz

#define  T1       0        // Tiempo 1
#define  T2       32       // Tiempo 2
#define  T3       64       // Tiempo 3
#define  T4       96       // Tiempo 4
#define  T6       128      // Tiempo 6
#define  T8       160      // Tiempo 8
#define  T12      192      // Tiempo 12


#define  Z0       ( 224)   // Pausa Tiempo 0
#define  Z1       (Z0+1)   // Pausa Tiempo 1
#define  Z2       (Z0+2)   // Pausa Tiempo 2
#define  Z3       (Z0+3)   // Pausa Tiempo 3
#define  Z4       (Z0+4)   // Pausa Tiempo 4
#define  Z6       (Z0+5)   // Pausa Tiempo 6
#define  Z8       (Z0+6)   // Pausa Tiempo 8
#define  Z12      (Z0+7)   // Pausa Tiempo 12
#define  Z16      (Z0+8)   // Pausa Tiempo 16
#define  Z24      (Z0+9)   // Pausa Tiempo 24
#define  Z32      (Z0+10)  // Pausa Tiempo 32

#define OCTAVE_1   (Z0+11) 
#define OCTAVE_2   (Z0+12) 
#define OCTAVE_3   (Z0+13) 
#define OCTAVE_4   (Z0+14) 
#define OCTAVE_5   (Z0+15) 
#define OCTAVE_6   (Z0+16) 
#define OCTAVE_7   (Z0+17) 
#define OCTAVE_8   (Z0+18) 
#define OCTAVE_9   (Z0+19) 

#define END_SONG   (0xFF) 

#endif
