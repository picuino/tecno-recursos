/*
   Picuino.cpp - Picuino Project Board library for Arduino & Wiring
   Copyright (c) 2015 Carlos Pardo Martin. All right reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 3 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

*/
#ifndef __PICUINO_H
#define __PICUINO_H

#include <stdlib.h>
#include <inttypes.h>
#include "utility/notes.h"
#include "utility/seven_segment.h"

#define DEBUG

/****************************************************************
   MACROS
 ****************************************************************/
 #define IS_IN(byte, mask) ((byte & mask) != 0)

/****************************************************************
   COMANDS
 ****************************************************************/
#define CMD_NOP             0x00
#define CMD_ERROR           0xFF

#define CMD_SYSTEM          0x08
#define CMD_COMMAND         0x10
#define CMD_KEYB            0x18
#define CMD_LED             0x20
#define CMD_DISPLAY         0x28
#define CMD_BUZZER          0x30
#define CMD_PLAY            0x38
#define CMD_WIFI            0x40

#define CMD_TYPE_MASK       0x07   // Command mask for command type

#define CMD_BEGIN           0x00   // Module initialization
#define CMD_CONFIG          0x01   // Module configuration
#define CMD_WRITE           0x02   // Write data: Arduino -> Picuino
#define CMD_READ            0x03   // Read data:  Picuino -> Arduino
#define CMD_READRST         0x04   // Read and reset data: Picuino -> Arduino
#define CMD_SEND            0x05   // Write bulk data: Arduino -> Picuino
#define CMD_RECEIVE         0x06   // Read bulk data:  Picuino -> Arduino
#define CMD_FUNC4           0x07

#define CMD_KEY_VALUE       0x00
#define CMD_KEY_PRESSED     0x10
#define CMD_KEY_TOGGLE      0x20
#define CMD_KEY_EVENTS      0x30
#define CMD_KEY_COUNT       0x40
#define CMD_KEY_TIMEON      0x50
#define CMD_KEY_TIMEOFF     0x60
#define CMD_KEY_PRESSED_ALL 0x70


/****************************************************************
   CONSTANTS
 ****************************************************************/
#define WIRE_BUFFER_SIZE      32
#define WIRE_MAX_WAIT        100
#define WIRE_ADDR             90


//
//   LED
//
#define LED_NUM_MAX          (8)
#define LED_ON            (0xFF)
#define LED_OFF           (0x00)


//
//   DISPLAY
//
#define DISPLAY_NUM_DIGIT    (4)
#define DISPLAY_DOT_1       0x01
#define DISPLAY_DOT_2       0x02
#define DISPLAY_DOT_3       0x04
#define DISPLAY_DOT_4       0x08
#define DISPLAY_DOTS        0x00


//
//   KEYBOARD
//
#define KEY_NUM_MAX          (6)

#define KEY_PRESSED_TIME1   0x01
#define KEY_PRESSED_TIME2   0x02
#define KEY_PRESSED_TIME3   0x04
#define KEY_RELEASED        0x08

#define KEY_ALL                0
#define KEY_LEFT               1
#define KEY_RIGHT              2
#define KEY_UP                 3
#define KEY_DOWN               4
#define KEY_ENTER              5
#define KEY_BACK               6


//
//   WIFI
//
#define WIFI_9600_BAUD         1
#define WIFI_19200_BAUD        2
#define WIFI_28800_BAUD        3
#define WIFI_38400_BAUD        4
#define WIFI_57600_BAUD        6
#define WIFI_115200_BAUD      12
#define WIFI_230400_BAUD      24


#define WIFI_ENABLE            0
#define WIFI_DISABLE           1
#define WIFI_RESET             2
#define WIFI_MODE_STATION      3
#define WIFI_MODE_AP           4
#define WIFI_MODE_BOTH         5
#define WIFI_GET_IP            6
#define WIFI_SINGLE_CONN       7
#define WIFI_MULTIPLE_CONN     8
#define WIFI_START_WEB         9
#define WIFI_CLOSE            10
#define WIFI_QUIT_AP          11
#define WIFI_JOIN             12


#define CMD_SEND_SIZE          16


/****************************************************************
   DATA TYPES
 ****************************************************************/



/****************************************************************
   CLASS DECLARATION
 ****************************************************************/
class Picuino {
   // PRIVATE DATA AND METHODS
   private:
   #ifdef DEBUG
   #warning "CAUTION: DEBUG ACTIVE"
   public:
   #endif

      // Private Data
      static uint8_t Buff[];

      // Private Methods
      void WireSendBuff(uint8_t bytes);
      void WireReadBuff(uint8_t bytes);
      void SendCommand(uint8_t bytes);
      uint8_t WireReadChar(void);

      uint8_t strcpy(char *o, char *d);

   // PUBLIC DATA AND METHODS
   #ifndef DEBUG
   public:
   #endif

      // Constructor
      Picuino();

      // Public Methods
      void begin(void);

      // KEYBOARD METHODS
      void keyBegin(void);
      void keyBegin(uint8_t filter, uint8_t time1,
                    uint8_t time2, uint8_t time3,
                    uint8_t repeat2, uint8_t repeat3);
      uint8_t keyValue(uint8_t keyNum);
      uint8_t keyPressed(uint8_t keyNum);
      uint8_t keyToggle(uint8_t keyNum);
      uint8_t keyEvents(uint8_t keyNum);
      uint8_t keyCount(uint8_t keyNum);
      uint16_t keyTimeOn(uint8_t keyNum);
      uint8_t keyTimeOff(uint8_t keyNum);

      // LED METHODS
      void ledBegin(void);
      void ledWrite(uint8_t ledNum, uint8_t value);
      void ledBlink(uint8_t ledNum, uint16_t time_on, uint16_t time_off);
      void ledBright(uint8_t ledNum, uint8_t value);

      // DISPLAY METHODS
      void dispBegin(void);
      void dispWrite(int number);
      void dispWrite(uint8_t digitNum, uint8_t segments);
      void dispWrite(uint8_t, uint8_t, uint8_t, uint8_t);
      void dispDigit(uint8_t digitNum, uint8_t number);
      void dispDots(uint8_t dots);

      // BUZZER METHODS
      void buzzBegin(void);
      uint8_t buzzRead(void);
      void buzzTone(float frequency);
      void buzzTone(int frequency);
      void buzzPlay(uint8_t Tone, uint8_t Time);

      // WIFI METHODS
      void wifiBegin(void);
      void wifiCommand(uint8_t command);
      uint8_t wifiRead(void);

};


extern Picuino pio;

#endif
