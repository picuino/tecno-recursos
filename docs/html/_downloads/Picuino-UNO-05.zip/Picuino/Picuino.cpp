/*
   Picuino.cpp - Picuino Project Board library for Arduino & Wiring
   Copyright (c) 2015 Carlos Pardo Martin. All right reserved.

   This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 3 of the License, or (at your option) any later version.

   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
   Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
   02110-1301  USA

*/

#include <stdlib.h>
#include <inttypes.h>
#include <arduino.h>
#include "utility/Wire.h"
#include "Picuino.h"



// Initialize Class Variables //////////////////////////////////////////////////

uint8_t Picuino::Buff[WIRE_BUFFER_SIZE];


/******************************************************************************
   PRIVATE METHODS
 ******************************************************************************/

/////////////////////////////////////////////////////////////////
void Picuino::WireSendBuff(uint8_t bytes) {
   uint8_t *p;
   if (bytes > WIRE_BUFFER_SIZE)
      bytes = WIRE_BUFFER_SIZE;
   p = Buff;
   Wire.beginTransmission(WIRE_ADDR);
   while(bytes--) {
      Wire.write(*p++);
   }
   Wire.endTransmission();           // Stop transmitting
};


/////////////////////////////////////////////////////////////////
void Picuino::SendCommand(uint8_t bytes) {
   WireSendBuff(bytes);
   delayMicroseconds(250);
}

/////////////////////////////////////////////////////////////////
uint8_t Picuino::WireReadChar(void) {
   uint8_t i;
   for(i = WIRE_MAX_WAIT; ; i--) {
      if (Wire.available()) {
         return Wire.read();
         break;
      }
      if (i == 0) {
         return CMD_ERROR;
      }
      delayMicroseconds(100);
   }
}


/////////////////////////////////////////////////////////////////
void Picuino::WireReadBuff(uint8_t bytes) {
   uint8_t *p, c;
   if (bytes == 0) return;

   Wire.requestFrom((uint8_t)WIRE_ADDR, bytes);  // request bytes from slave device
   Buff[0] = WireReadChar();
   if (Buff[0] == CMD_ERROR) {
     Wire.endTransmission();
     return;
   }

   for(p=&Buff[1]; --bytes;) {
      *p++ = WireReadChar();
   }
}

/*
void Picuino::WireReadCommand(uint8_t bytes) {
   for(char i = WIRE_MAX_WAIT;; i--) {
      WireReadBuff(bytes);

}
*/

/******************************************************************************
   PUBLIC METHODS
 ******************************************************************************/

// Constructors ////////////////////////////////////////////////////////////////
Picuino::Picuino() {
}

/////////////////////////////////////////////////////////////////
void Picuino::begin(void) {
   Wire.begin();
   keyBegin();
   ledBegin();
   dispBegin();
   buzzBegin();
}


/****************************************************************
   LED METHODS
 ****************************************************************/

/////////////////////////////////////////////////////////////////
void Picuino::ledBegin(void) {
   // Inits leds state
   Buff[0] = CMD_LED + CMD_BEGIN;
   SendCommand(1);
}

/////////////////////////////////////////////////////////////////
void Picuino::ledWrite(uint8_t ledNum, uint8_t bright) {
   // Switch led on and off
   if (ledNum > LED_NUM_MAX)
      return;
   if (bright == 1)
      bright = LED_ON;
   Buff[0] = CMD_LED + CMD_WRITE;
   Buff[1] = ledNum;
   Buff[2] = bright;
   SendCommand(3);
}

/////////////////////////////////////////////////////////////////
void Picuino::ledBright(uint8_t ledNum, uint8_t bright) {
   // Change led bright
   if (ledNum > LED_NUM_MAX)
      return;
   Buff[0] = CMD_LED + CMD_WRITE;
   Buff[1] = 0x80 + (ledNum & 0x0F);
   Buff[2] = bright;
   SendCommand(3);
}

/////////////////////////////////////////////////////////////////
void Picuino::ledBlink(uint8_t ledNum, uint16_t time_on, uint16_t time_off) {
   // Blink led with time_on and time_off
   if (ledNum > LED_NUM_MAX)
      return;
   Buff[0] = CMD_LED + CMD_WRITE;
   Buff[1] = ledNum;
   Buff[2] = time_on;
   Buff[3] = time_on>>8;
   Buff[4] = time_off;
   Buff[5] = time_off>>8;
   SendCommand(6);
}


/****************************************************************
   KEYBOARD METHODS
 ****************************************************************/

/////////////////////////////////////////////////////////////////
void Picuino::keyBegin(void) {
   // Init keyboard state
   Buff[0] = CMD_KEYB + CMD_BEGIN;
   SendCommand(1);
}

void Picuino::keyBegin(uint8_t filter,
                       uint8_t time1,
                       uint8_t time2,
                       uint8_t time3,
                       uint8_t repeat2,
                       uint8_t repeat3) {
   // Init keyboard state
   Buff[1] = filter;   // Filter time
   Buff[2] = time1;    // Time1
   Buff[3] = time2;    // Time2
   Buff[4] = (uint8_t)(time3 & 0xFF);  // Time3
   Buff[5] = (uint8_t)(time3 >> 8);    // Time3
   Buff[6] = repeat2;  // Repeat2
   Buff[7] = repeat3;  // Repeat3
   SendCommand(8);
}


/////////////////////////////////////////////////////////////////
uint8_t Picuino::keyValue(uint8_t keyNum) {
   if (keyNum > KEY_NUM_MAX) return 0;
   Buff[0] = CMD_KEYB + CMD_READ;
   Buff[1] = CMD_KEY_VALUE | keyNum;
   SendCommand(2);
   WireReadBuff(2);
   return Buff[1];
}

uint8_t Picuino::keyPressed(uint8_t keyNum) {
   if (keyNum > KEY_NUM_MAX) return 0;
   if (keyNum == 0) {
      Buff[0] = CMD_KEYB + CMD_READ;
      Buff[1] = CMD_KEY_PRESSED_ALL;
      SendCommand(2);
      WireReadBuff(2);
      return Buff[1];
   }
   else {
      Buff[0] = CMD_KEYB + CMD_READ;
      Buff[1] = CMD_KEY_PRESSED | keyNum;
      SendCommand(2);
      WireReadBuff(2);
      return Buff[1];
   }
}

uint8_t Picuino::keyToggle(uint8_t keyNum) {
   if (keyNum > KEY_NUM_MAX) return 0;
   Buff[0] = CMD_KEYB + CMD_READ;
   Buff[1] = CMD_KEY_TOGGLE | keyNum;
   SendCommand(2);
   WireReadBuff(2);
   return Buff[1];
}

uint8_t Picuino::keyEvents(uint8_t keyNum) {
   if (keyNum > KEY_NUM_MAX) return 0;
   Buff[0] = CMD_KEYB + CMD_READRST;
   Buff[1] = CMD_KEY_EVENTS + keyNum;
   SendCommand(2);
   WireReadBuff(2);
   return Buff[1];
}

uint8_t Picuino::keyCount(uint8_t keyNum) {
   if (keyNum > KEY_NUM_MAX) return 0;
   Buff[0] = CMD_KEYB + CMD_READRST;
   Buff[1] = CMD_KEY_COUNT + keyNum;
   SendCommand(2);
   WireReadBuff(2);
   return Buff[1];
}

uint16_t Picuino::keyTimeOn(uint8_t keyNum) {
   if (keyNum > KEY_NUM_MAX) return 0;
   Buff[0] = CMD_KEYB + CMD_READ;
   Buff[1] = CMD_KEY_TIMEON + keyNum;
   SendCommand(2);
   WireReadBuff(3);
   return *(int *)(&Buff[1]);
}

uint8_t Picuino::keyTimeOff(uint8_t keyNum) {
   if (keyNum > KEY_NUM_MAX) return 0;
   Buff[0] = CMD_KEYB + CMD_READ;
   Buff[1] = CMD_KEY_TIMEOFF + keyNum;
   SendCommand(2);
   WireReadBuff(2);
   return Buff[1];
}



/****************************************************************
   DISPLAY METHODS
 ****************************************************************/

/////////////////////////////////////////////////////////////////
void Picuino::dispBegin(void) {
   // Init display state
   Buff[0] = CMD_DISPLAY + CMD_BEGIN;
   SendCommand(1);
}


/////////////////////////////////////////////////////////////////
void Picuino::dispWrite(int number) {
   // Display 4 digit number
   if (number < 0) number = -number;
   Buff[0] = CMD_DISPLAY + CMD_WRITE;
   Buff[1] = 0x80 | (number >> 8);
   Buff[2] = number & 0xFF;
   SendCommand(3);
}

void Picuino::dispWrite(uint8_t digitNum, uint8_t segments) {
   // Display segments in digit
   if (digitNum > DISPLAY_NUM_DIGIT || digitNum == 0)
      return;
   Buff[0] = CMD_DISPLAY + CMD_WRITE;
   Buff[1] = digitNum;
   Buff[2] = segments;
   SendCommand(3);
}


/////////////////////////////////////////////////////////////////
void Picuino::dispDots(uint8_t dots) {
   // Display dots
   Buff[0] = CMD_DISPLAY + CMD_WRITE;
   Buff[1] = 0;
   Buff[2] = dots;
   SendCommand(3);
}

/////////////////////////////////////////////////////////////////
void Picuino::dispDigit(uint8_t digitNum, uint8_t number) {
   // Display 1 digit number
   const uint8_t segments[] = {
      SS_0, SS_1, SS_2, SS_3, SS_4,
      SS_5, SS_6, SS_7, SS_8, SS_9,
      SS_A, SS_b, SS_C, SS_d, SS_E,  SS_F,
   };
   if (digitNum > DISPLAY_NUM_DIGIT || digitNum == 0)
      return;
   if (number > sizeof(segments))
      return;
   Buff[0] = CMD_DISPLAY + CMD_WRITE;
   Buff[1] = digitNum & 0x0F;
   Buff[2] = segments[number];
   SendCommand(3);
}

void Picuino::dispWrite(uint8_t dig1, uint8_t dig2, uint8_t dig3, uint8_t dig4) {
  // Display string
   Buff[0] = CMD_DISPLAY + CMD_WRITE;
   Buff[1] = dig1;
   Buff[2] = dig2;
   Buff[3] = dig3;
   Buff[4] = dig4;
   SendCommand(5);
}

/****************************************************************
   BUZZER METHODS
 ****************************************************************/

/////////////////////////////////////////////////////////////////
void Picuino::buzzBegin(void) {
   // Init buzzer state
   Buff[0] = CMD_BUZZER + CMD_BEGIN;
   SendCommand(1);
}

/////////////////////////////////////////////////////////////////
uint8_t Picuino::buzzRead(void) {
   // Read buzzer state
   Buff[0] = CMD_BUZZER + CMD_READ;
   SendCommand(1);
   WireReadBuff(2);
   return(Buff[1]);
}

/////////////////////////////////////////////////////////////////
void Picuino::buzzTone(float frequency) {
   // Buzz frequency
   uint32_t freq;

   if (frequency > 32767.0)
      freq = 32767L * 256;
   else if (frequency < 0.0)
      freq = 0L;
   else
      freq = (frequency * 256.0);

   Buff[0] = CMD_BUZZER + CMD_WRITE;
   Buff[1] = *(((uint8_t *)&freq)+0);
   Buff[2] = *(((uint8_t *)&freq)+1);
   Buff[3] = *(((uint8_t *)&freq)+2);
   Buff[4] = *(((uint8_t *)&freq)+3);
   SendCommand(5);
}

void Picuino::buzzTone(int frequency) {
   // Buzz frequency
   if (frequency < 0)
      frequency = 0;

   Buff[0] = CMD_BUZZER + CMD_WRITE;
   Buff[1] = *(((uint8_t *)&frequency)+0);
   Buff[2] = *(((uint8_t *)&frequency)+1);
   SendCommand(3);
}


/////////////////////////////////////////////////////////////////
void Picuino::buzzPlay(uint8_t Tone, uint8_t Time) {
   // Play Note with time
   Buff[0] = CMD_PLAY + CMD_WRITE;
   Buff[1] = Tone;
   Buff[2] = Time;
   SendCommand(3);
}


/****************************************************************
   WIFI METHODS
 ****************************************************************/

/////////////////////////////////////////////////////////////////
void Picuino::wifiBegin(void) {
   // Init wifi state
   Buff[0] = CMD_WIFI + CMD_BEGIN;
   SendCommand(1);
}

/////////////////////////////////////////////////////////////////
void Picuino::wifiCommand(uint8_t command) {
   Buff[0] = CMD_WIFI + CMD_WRITE;
   switch (command) {
   case WIFI_ENABLE:
      Buff[1] = WIFI_ENABLE;
      break;
   case WIFI_DISABLE:
      Buff[1] = WIFI_DISABLE;
      break;
   case WIFI_RESET:
      Buff[1] = WIFI_RESET;
      break;
   case WIFI_MODE_STATION:
      Buff[1] = WIFI_MODE_STATION;
      break;
   case WIFI_MODE_AP:
      Buff[1] = WIFI_MODE_AP;
      break;
   case WIFI_MODE_BOTH:
      Buff[1] = WIFI_MODE_BOTH;
      break;
   case WIFI_SINGLE_CONN:
      Buff[1] = WIFI_SINGLE_CONN;
      break;
   case WIFI_MULTIPLE_CONN:
      Buff[1] = WIFI_MULTIPLE_CONN;
      break;
   case WIFI_GET_IP:
      Buff[1] = WIFI_GET_IP;
      break;
   case WIFI_START_WEB:
      Buff[1] = WIFI_START_WEB;
      break;
   case WIFI_CLOSE:
      Buff[1] = WIFI_CLOSE;
      break;
   case WIFI_QUIT_AP:
      Buff[1] = WIFI_QUIT_AP;
      break;
   case WIFI_JOIN:
      Buff[1] = WIFI_JOIN;
      break;
   default:
      Buff[0] = CMD_ERROR;
      return;
   }
   SendCommand(2);
}


uint8_t Picuino::wifiRead(void) {
   Buff[0] = CMD_WIFI + CMD_READ;
   SendCommand(1);
   WireReadBuff(17);
   return Buff[1];
}


// Preinstantiate Objects //////////////////////////////////////////////////////
Picuino pio = Picuino();

/************************* END **************************/
